package com.Mailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicMailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
